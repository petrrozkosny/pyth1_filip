from tools import funkce
funkce.moje_funkce()