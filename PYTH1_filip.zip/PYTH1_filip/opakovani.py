# 1. Do proměnné vstup uložit vstup uživatele, kde uživatele žádáme o číslo
vstup = input("Zadejte číslo: ")
#  Slovník s 3 největšími městy ČR, kdy klíč se bude rovnat pořadí a hodnota se bude rovnat 
# název města
data = {
    "1":"Praha",
    "2":"Brno",
    "3": "Ostrava"
}
# Otestujeme, jestli uživatel zadal číslo větší či rovno 1 a menší či rovno 3
# pokud ne, vypíšeme: Číslo nesplňuje podmínku 1-3
# pokud ano, vypíšeme název města na daném čísle (pozici)

if vstup != "":
    if int(vstup) >=1 and int(vstup)<=3:    
        print(data[vstup])
