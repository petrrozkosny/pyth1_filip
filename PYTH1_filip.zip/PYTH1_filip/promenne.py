
mesto = "Kraborovice"
def vnejsi_funkce():
    print(mesto) # Jestli a co se vytiskne?
    mesto = 'Olomouc'

    def vnitrni_funkce():
        nonlocal mesto
        mesto = 'Zlín'

    vnitrni_funkce()
    print('Po volání vnitřní funkce:', mesto)

vnejsi_funkce()
print(mesto)