import pandas as pd
import re
soubor = "pythdata.xlsx"
soubor = soubor.strip() # nadbytecne mezery na zacatku a konci
soubor = re.sub(r'[^\x20-\x7E]', '', soubor) # odstranuje netisknutelne znaky 
df = pd.read_excel(soubor)
foo =1

dir(df)
globals()