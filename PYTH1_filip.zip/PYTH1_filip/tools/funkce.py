
def moje_funkce(a:str,b:str)->None:
    """
    Hledá dílčí text v textu.
    Výsledek tiskne do konzole

    Parametry:
    a (str): Dílčí textový řetěze, který hledáme.
    b (str): Textový řetězec, ve kterém hledáme.
    
    Return: None
    """
    print(a in b)